                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2047554
TUSH - The Ultimate Spool Holder by terrago is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Introducing TUSH - The Ultimate Spool Holder v.2. I was using a regular spool holder. Not the most convenient design, if you ask me, because It takes some time to replace the roll. Also, based on 608 bearings, It gives more than requested length of filament since there is no traction. That's why I designed this Ultimate Spool Holder. It is simple, easy, sexy and comfy. 
For one spool holder you will need to print four pieces of this. Also, you will need four 608 bearings. Get the cheapest ones. They are available everywhere. This is press-fit design. Just press the bearings into the printed part, and voila, you have The Ultimate Spool Holder! Congratulations!

UPDATE: Version 2 uploaded
This is exactly the same TUSH. Just some fixes. Now Simplify3D ans slic3r should be happy with the model. Cheers!

# Print Settings

Printer: Anet A8
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20